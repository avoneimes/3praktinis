import React from "react";

// Naudojame React.memo, kad išvengtume nereikalingo renderinimo
const UserCard = React.memo(({ user }) => {
    return (
        <div style={{ border: "1px solid #ccc", padding: "10px", margin: "5px" }}>
            <h3>{user.name}</h3> {/* Rodo naudotojo vardą */}
            <p>{user.email}</p> {/* Rodo naudotojo el. paštą */}
            <p>{user.address.city}</p> {/* Rodo miestą */}
        </div>
    );
});

export default UserCard;
