const SearchBar = ({ searchTerm, setSearchTerm }) => {
    return (
        <div>
            <input
                type="text"
                placeholder="Ieškoti naudotojo..."
                value={searchTerm} // Susiejame su būsenos reikšme
                onChange={(e) => setSearchTerm(e.target.value)} // Atnaujiname būseną
            />
            <button onClick={() => setSearchTerm("")}>Valyti</button> {/* Pašalina paieškos tekstą */}
        </div>
    );
};

export default SearchBar;
