import React, { useMemo } from "react";
import UserCard from "./UserCard"; // Importuojame vieno naudotojo kortelę

const UserList = ({ users, searchTerm }) => {
    // Optimizuojame paiešką su useMemo (saugo rezultatą tarp renderių)
    const filteredUsers = useMemo(() => {
        return users.filter((user) =>
            user.name.toLowerCase().includes(searchTerm.toLowerCase()) // Filtruojame pagal vardą
        );
    }, [users, searchTerm]);

    if (filteredUsers.length === 0) {
        return <p>Naudotojų nerasta.</p>; // Jei nėra rezultatų
    }

    return (
        <div>
            {filteredUsers.map((user) => (
                <UserCard key={user.id} user={user} /> // Atvaizduojame naudotojų korteles
            ))}
        </div>
    );
};

export default UserList;
