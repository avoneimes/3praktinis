import { useState, useEffect, useCallback } from "react"; // Importuojame React hooks
import SearchBar from "./components/SearchBar"; // Importuojame paieškos juostą
import UserList from "./components/UserList"; // Importuojame naudotojų sąrašą
import "./App.css"; // Importuojame stilius

// 🎯 Funkcija sugeneruoti bent 100 naudotojų (dirbtiniai duomenys)
const generateFakeUsers = (count) => {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1, // Unikalus ID
    name: `Naudotojas ${i + 1}`, // Sugeneruotas vardas
    email: `naudotojas${i + 1}@email.com`, // Sugeneruotas el. paštas
    address: { city: `Miestas ${i % 10}` }, // Keičiasi kas 10 vartotojų
  }));
};

const App = () => {
  const [users, setUsers] = useState([]); // Valstybė naudotojų sąrašui
  const [searchTerm, setSearchTerm] = useState(""); // Valstybė paieškos laukui
  const [loading, setLoading] = useState(true); // Įkėlimo būsena

  //  Duomenų užklausimas iš API (naudotojų sąrašas)
  useEffect(() => {
    // sugeneruojame 100 naudotojų
    const fakeUsers = generateFakeUsers(100);
    setUsers(fakeUsers); // Išsaugome sugeneruotus vartotojus į state
    setLoading(false); // Baigiame įkėlimo režimą
  }, []); // useEffect veiks tik vieną kartą užkrovus komponentą

  // Optimizuota paieškos funkcija naudojant useCallback
  const handleSearch = useCallback((term) => {
    setSearchTerm(term); // Nustatome paieškos reikšmę
  }, []); // Funkcija nebus kuriama iš naujo su kiekvienu renderiu

  return (
    <div className="container">
      <h1>Naudotojų paieška</h1>

      {/* Paieškos komponentas - perduodame paieškos reikšmę ir funkciją */}
      <SearchBar searchTerm={searchTerm} setSearchTerm={handleSearch} />

      {/* Jei duomenys kraunami - rodyti "Kraunama...", jei ne - rodyti sąrašą */}
      {loading ? <p>Kraunama...</p> : <UserList users={users} searchTerm={searchTerm} />}
    </div>
  );
};

export default App;
