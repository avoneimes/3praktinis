import { useState, useEffect, useCallback } from "react";
import SearchBar from "./components/SearchBar"; // Importuojame paieškos juostą
import UserList from "./components/UserList"; // Importuojame naudotojų sąrašą
import "./App.css"; // Importuojame stilius

const App = () => {
  const [users, setUsers] = useState([]); // Valstybė naudotojų sąrašui
  const [searchTerm, setSearchTerm] = useState(""); // Valstybė paieškos laukui
  const [loading, setLoading] = useState(true); // Įkėlimo būsena

  // Duomenų užklausimas iš API (naudotojų sąrašas)
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => res.json()) // Konvertuojame į JSON formatą
      .then((data) => {
        setUsers(data); // Išsaugome naudotojus į state
        setLoading(false); // Baigiame įkėlimo režimą
      })
      .catch(() => setLoading(false)); // Jei klaida, išjungiame įkėlimą
  }, []);

  // Optimizuota paieškos funkcija naudojant useCallback
  const handleSearch = useCallback((term) => {
    setSearchTerm(term);
  }, []);

  return (
    <div className="container">
      <h1>Naudotojų paieška</h1>
      <SearchBar searchTerm={searchTerm} setSearchTerm={handleSearch} />
      {loading ? <p>Kraunama...</p> : <UserList users={users} searchTerm={searchTerm} />}
    </div>
  );
};

export default App;
